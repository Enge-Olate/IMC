Projeto para calcular o índice de massa corporal(IMC) de forma rápida e facil.
Treino Front-End!
