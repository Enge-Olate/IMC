#!bin/bash
#variáveis
TEXT_YELLOW="\e[0;33m"
TEXT_RESET="\e[0m"
#função para printar avisos com a cor amarela no texto
print_yellow_message(){
    echo  $TEXT_YELLOW    
    echo  "$1"
    echo  $TEXT_RESET
    sleep 1
}

#Comandos para atualizar o sistema operacional
sudo apt-get update && sudo apt-get upgrade -y
sudo apt-get dist-upgrade -y

#Comandos para remover e limpar pacotes
sudo apt-get autoremove
sudo apt-get autoclean
print_yellow_message "Removido com sucesso!"
print_yellow_message "Sistema limpo!"

