#include<stdio.h>
#include<stdlib.h>
int main(){

int *a, p;
a = 10;
p = &a;
a = 8;
printf("%d\n %d", a, p);

}
